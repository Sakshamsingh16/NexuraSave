# Nexura Save

An Android app starter with a soft pastel Claymorphism UI (puffy 3D cards, brand icons). Save shared links/text and create notes locally, search the library, filter by type, and favorite/delete items.

## Build APK on GitHub
1. Create a new GitHub repository named `NexuraSave`.
2. Upload the contents of this folder to the repository root (including `.github/workflows/build-apk.yml`).
3. Open **Actions** and run **Build Nexura Save APK**, or push to `main`/`master`.
4. Open the successful workflow run and download the `NexuraSave-debug-apk` artifact.

## Build locally
Requires JDK 17, Android SDK 35 and Gradle 8.7:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Current functionality
- Receives Android Share intents for text, image and video MIME types.
- Local library stored in app-private SharedPreferences.
- Manual note/link saving, search, category filters, favorites and delete.
- Tap a saved link to open it in its own app (YouTube, Instagram, Facebook, X, WhatsApp, Telegram, TikTok, LinkedIn, Pinterest, Reddit, Snapchat, Threads); falls back to the browser if the app isn't installed.
- No login, external server or API key.

## Important limitations
- Shared image/video URIs are currently recorded as references, not copied into permanent app storage; some source apps provide temporary URIs. Downloading the original media is not guaranteed.
- `SEND_MULTIPLE` is registered for media sharing, but the first version focuses on a single shared item. Multi-file import and persistent media copying can be added next.
- This is source code, not a prebuilt APK. Use the included GitHub Actions workflow to compile it.
