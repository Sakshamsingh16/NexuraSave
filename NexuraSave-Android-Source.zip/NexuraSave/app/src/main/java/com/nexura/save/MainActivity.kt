package com.nexura.save

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

// ---------- Claymorphism palette ----------
private val BgTop = Color(0xFFF4F1FF)
private val BgBottom = Color(0xFFE4E0FA)
private val ClayCard = Color(0xFFF3F0FF)
private val ClayShadow = Color(0xFF8F86CF)
private val Ink = Color(0xFF2B2760)
private val Muted = Color(0xFF8782B8)
private val Purple = Color(0xFF7C6CFF)
private val PurpleSoft = Color(0xFFB0A4FF)
private val Pink = Color(0xFFFF5C9A)
private val PinkSoft = Color(0xFFFF9EC4)
private val Mint = Color(0xFF3FD6A3)
private val MintSoft = Color(0xFF9AF0D3)
private val Sunny = Color(0xFFFFB92E)
private val SunnySoft = Color(0xFFFFE08F)
private val Sky = Color(0xFF3DB5FF)
private val SkySoft = Color(0xFF9FDEFF)
private val Danger = Color(0xFFFF7A92)

private fun grad(a: Color, b: Color) = Brush.linearGradient(listOf(a, b))

// ---------- Data ----------
data class SavedItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val content: String,
    val kind: String,
    val source: String = "Manual",
    val created: Long = System.currentTimeMillis(),
    val favorite: Boolean = false
)

private data class Brand(
    val id: String,
    val label: String,
    val pkg: String?,
    val hosts: List<String>,
    val c1: Color,
    val c2: Color
)

private val BRANDS = listOf(
    Brand("youtube", "YouTube", "com.google.android.youtube", listOf("youtube.com", "youtu.be"), Color(0xFFFF7A7A), Color(0xFFE62117)),
    Brand("instagram", "Instagram", "com.instagram.android", listOf("instagram.com", "instagr.am"), Color(0xFFFFA24C), Color(0xFFD62976)),
    Brand("facebook", "Facebook", "com.facebook.katana", listOf("facebook.com", "fb.com", "fb.watch", "fb.me"), Color(0xFF5AA2FF), Color(0xFF1877F2)),
    Brand("x", "X", "com.twitter.android", listOf("x.com", "twitter.com", "t.co"), Color(0xFF55556F), Color(0xFF16161F)),
    Brand("whatsapp", "WhatsApp", "com.whatsapp", listOf("whatsapp.com", "wa.me"), Color(0xFF66E896), Color(0xFF1FB855)),
    Brand("telegram", "Telegram", "org.telegram.messenger", listOf("t.me", "telegram.me", "telegram.org"), Color(0xFF72CFFF), Color(0xFF229ED9)),
    Brand("tiktok", "TikTok", "com.zhiliaoapp.musically", listOf("tiktok.com"), Color(0xFF45455A), Color(0xFF0E0E14)),
    Brand("linkedin", "LinkedIn", "com.linkedin.android", listOf("linkedin.com", "lnkd.in"), Color(0xFF4AA3E8), Color(0xFF0A66C2)),
    Brand("pinterest", "Pinterest", "com.pinterest", listOf("pinterest.com", "pin.it"), Color(0xFFFF7080), Color(0xFFE60023)),
    Brand("reddit", "Reddit", "com.reddit.frontpage", listOf("reddit.com", "redd.it"), Color(0xFFFF9456), Color(0xFFFF4500)),
    Brand("snapchat", "Snapchat", "com.snapchat.android", listOf("snapchat.com"), Color(0xFFFFF176), Color(0xFFFFC800)),
    Brand("threads", "Threads", "com.instagram.barcelona", listOf("threads.net", "threads.com"), Color(0xFF55556F), Color(0xFF16161F))
)
private val WEB = Brand("web", "Website", null, emptyList(), PurpleSoft, Purple)
private val VIDEO = Brand("video", "Video", null, emptyList(), PinkSoft, Pink)
private val IMAGE = Brand("image", "Image", null, emptyList(), MintSoft, Mint)
private val NOTE = Brand("note", "Note", null, emptyList(), SunnySoft, Sunny)

private fun extractUrl(text: String): String? {
    val m = Regex("""(https?://|www\.)[^\s]+""", RegexOption.IGNORE_CASE).find(text) ?: return null
    val raw = m.value.trimEnd('.', ',', ')', ']', '"', '\'', '!')
    return if (raw.startsWith("www.", ignoreCase = true)) "https://$raw" else raw
}

private fun detectBrand(url: String): Brand? {
    val host = try { Uri.parse(url).host.orEmpty().lowercase(Locale.ROOT) } catch (_: Exception) { "" }
    return BRANDS.firstOrNull { b -> b.hosts.any { h -> host == h || host.endsWith(".$h") } }
}

private fun brandFor(item: SavedItem): Brand {
    val url = extractUrl(item.content)
    if (url != null) {
        val b = detectBrand(url)
        if (b != null) return b
    }
    return when (item.kind) {
        "Video" -> VIDEO
        "Image" -> IMAGE
        "Link" -> WEB
        else -> if (url != null) WEB else NOTE
    }
}

private fun actionLabel(item: SavedItem, brand: Brand): String = when {
    extractUrl(item.content) != null -> if (brand.pkg != null) "Open in ${brand.label}" else "Open in browser"
    item.kind == "Image" || item.kind == "Video" -> "Tap to view"
    else -> "Tap to copy"
}

// Tap on a saved item: opens the link in its own social media app (browser if app not installed)
private fun openItem(context: Context, item: SavedItem, notify: (String) -> Unit) {
    val url = extractUrl(item.content)
    if (url != null) {
        val brand = detectBrand(url)
        val uri = Uri.parse(url)
        if (brand?.pkg != null) {
            try {
                context.startActivity(
                    Intent(Intent.ACTION_VIEW, uri).setPackage(brand.pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                return
            } catch (_: Exception) {
                // app installed nahi hai ya link handle nahi kar paya -> browser fallback
            }
        }
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            notify("Link open nahi ho paaya")
        }
        return
    }
    if (item.content.startsWith("content://") || item.content.startsWith("file://")) {
        val mime = when (item.kind) { "Video" -> "video/*"; "Image" -> "image/*"; else -> "*/*" }
        try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(item.content), mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
            notify("File open nahi hui (source app ka access temporary tha)")
        }
        return
    }
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("Nexura Save", item.content))
    notify("Text copy ho gaya")
}

// ---------- Activity ----------
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val incoming = parseIncoming(intent)
        setContent { NexuraApp(this, incoming) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }

    private fun parseIncoming(i: Intent?): SavedItem? {
        if (i == null || (i.action != Intent.ACTION_SEND && i.action != Intent.ACTION_SEND_MULTIPLE)) return null
        val sharedText = i.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
        val subject = i.getStringExtra(Intent.EXTRA_SUBJECT).orEmpty()
        val uri = if (i.action == Intent.ACTION_SEND) i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM) else null
        val mime = i.type.orEmpty()
        val content = when {
            sharedText.isNotBlank() -> sharedText
            uri != null -> uri.toString()
            else -> "Shared content"
        }
        val kind = when {
            mime.startsWith("video/") -> "Video"
            mime.startsWith("image/") -> "Image"
            extractUrl(content) != null -> "Link"
            else -> "Text"
        }
        return SavedItem(title = subject.ifBlank { content.take(64).ifBlank { "Saved $kind" } }, content = content, kind = kind, source = "Share menu")
    }
}

// ---------- Clay building blocks ----------
private fun Modifier.clay(radius: Dp, fill: Brush, depth: Dp): Modifier = this.drawBehind {
    val r = radius.toPx()
    val d = depth.toPx()
    val steps = 6
    // soft dark shadow (bottom-right)
    for (i in steps downTo 1) {
        val g = d * i / steps
        drawRoundRect(
            color = ClayShadow.copy(alpha = 0.06f),
            topLeft = Offset(d * 0.5f - g, d * 0.7f - g),
            size = Size(size.width + 2 * g, size.height + 2 * g),
            cornerRadius = CornerRadius(r + g)
        )
    }
    // soft light glow (top-left)
    for (i in steps downTo 1) {
        val g = d * 0.8f * i / steps
        drawRoundRect(
            color = Color.White.copy(alpha = 0.16f),
            topLeft = Offset(-d * 0.45f - g, -d * 0.45f - g),
            size = Size(size.width + 2 * g, size.height + 2 * g),
            cornerRadius = CornerRadius(r + g)
        )
    }
    drawRoundRect(brush = fill, cornerRadius = CornerRadius(r))
    // puffy inner shading
    drawRoundRect(
        brush = Brush.linearGradient(
            listOf(Color.White.copy(alpha = 0.50f), Color.Transparent, ClayShadow.copy(alpha = 0.18f)),
            start = Offset.Zero,
            end = Offset(size.width, size.height)
        ),
        cornerRadius = CornerRadius(r)
    )
    // glossy rim
    val sw = 2.dp.toPx()
    drawRoundRect(
        brush = Brush.linearGradient(
            listOf(Color.White.copy(alpha = 0.9f), Color.Transparent, ClayShadow.copy(alpha = 0.35f)),
            start = Offset.Zero,
            end = Offset(size.width, size.height)
        ),
        topLeft = Offset(sw / 2, sw / 2),
        size = Size(size.width - sw, size.height - sw),
        cornerRadius = CornerRadius(r - sw / 2),
        style = Stroke(sw)
    )
}

private fun Modifier.clayInset(radius: Dp): Modifier = this.drawBehind {
    val r = radius.toPx()
    drawRoundRect(color = Color(0xFFE3DFFA), cornerRadius = CornerRadius(r))
    val sw = 3.dp.toPx()
    drawRoundRect(
        brush = Brush.linearGradient(
            listOf(ClayShadow.copy(alpha = 0.45f), Color.Transparent, Color.White.copy(alpha = 0.9f)),
            start = Offset.Zero,
            end = Offset(size.width, size.height)
        ),
        topLeft = Offset(sw / 2, sw / 2),
        size = Size(size.width - sw, size.height - sw),
        cornerRadius = CornerRadius(r - sw / 2),
        style = Stroke(sw)
    )
}

@Composable
private fun Clay(
    modifier: Modifier = Modifier,
    radius: Dp = 26.dp,
    color: Color = ClayCard,
    brush: Brush? = null,
    depth: Dp = 9.dp,
    onClick: (() -> Unit)? = null,
    contentAlignment: Alignment = Alignment.TopStart,
    content: @Composable BoxScope.() -> Unit
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.96f else 1f, label = "clayPress")
    var m = modifier.graphicsLayer { scaleX = scale; scaleY = scale }
        .clay(radius, brush ?: SolidColor(color), depth)
    if (onClick != null) m = m.clickable(interactionSource = source, indication = null, onClick = onClick)
    Box(m, contentAlignment = contentAlignment, content = content)
}

@Composable
private fun IconBadge(icon: ImageVector, c1: Color, c2: Color, dim: Dp = 40.dp) {
    Clay(Modifier.size(dim), radius = dim * 0.36f, brush = grad(c1, c2), depth = 4.dp, contentAlignment = Alignment.Center) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(dim * 0.52f))
    }
}

@Composable
private fun BrandGlyph(id: String, dim: Dp) {
    val g = dim * 0.5f
    val fs = (dim.value * 0.5f).sp
    when (id) {
        "youtube" -> Canvas(Modifier.size(g)) {
            val w = size.width
            val h = size.height
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(0f, h * 0.15f),
                size = Size(w, h * 0.7f),
                cornerRadius = CornerRadius(h * 0.22f)
            )
            val p = Path().apply {
                moveTo(w * 0.4f, h * 0.32f)
                lineTo(w * 0.4f, h * 0.68f)
                lineTo(w * 0.7f, h * 0.5f)
                close()
            }
            drawPath(p, Color(0xFFE62117))
        }
        "instagram" -> Canvas(Modifier.size(g)) {
            val s = size.width
            val sw = s * 0.11f
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(sw / 2, sw / 2),
                size = Size(s - sw, s - sw),
                cornerRadius = CornerRadius(s * 0.3f),
                style = Stroke(sw)
            )
            drawCircle(color = Color.White, radius = s * 0.2f, center = Offset(s / 2, s / 2), style = Stroke(sw))
            drawCircle(color = Color.White, radius = sw * 0.7f, center = Offset(s * 0.76f, s * 0.24f))
        }
        "facebook" -> Text("f", color = Color.White, fontSize = fs * 1.15f, fontWeight = FontWeight.Black)
        "x" -> Text("X", color = Color.White, fontSize = fs, fontWeight = FontWeight.Black)
        "whatsapp" -> Icon(Icons.Rounded.Call, null, Modifier.size(g), Color.White)
        "telegram" -> Icon(Icons.AutoMirrored.Rounded.Send, null, Modifier.size(g), Color.White)
        "tiktok" -> Icon(Icons.Rounded.MusicNote, null, Modifier.size(g), Color.White)
        "linkedin" -> Text("in", color = Color.White, fontSize = fs, fontWeight = FontWeight.Black)
        "pinterest" -> Text("P", color = Color.White, fontSize = fs, fontWeight = FontWeight.Black)
        "reddit" -> Text("R", color = Color.White, fontSize = fs, fontWeight = FontWeight.Black)
        "snapchat" -> Text("\uD83D\uDC7B", fontSize = fs)
        "threads" -> Text("@", color = Color.White, fontSize = fs, fontWeight = FontWeight.Black)
        "video" -> Icon(Icons.Rounded.Videocam, null, Modifier.size(g), Color.White)
        "image" -> Icon(Icons.Rounded.Image, null, Modifier.size(g), Color.White)
        "note" -> Icon(Icons.Rounded.StickyNote2, null, Modifier.size(g), Color.White)
        else -> Icon(Icons.Rounded.Public, null, Modifier.size(g), Color.White)
    }
}

@Composable
private fun BrandBadge(brand: Brand, dim: Dp = 54.dp) {
    Clay(Modifier.size(dim), radius = dim * 0.34f, brush = grad(brand.c1, brand.c2), depth = 5.dp, contentAlignment = Alignment.Center) {
        BrandGlyph(brand.id, dim)
    }
}

@Composable
private fun NavItem(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    val tint = if (selected) Purple else Muted
    Column(
        Modifier.clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(25.dp))
        Text(label, color = tint, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
    }
}

@Composable
private fun RowScope.KindChip(label: String, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    Clay(
        Modifier.weight(1f),
        radius = 18.dp,
        depth = 4.dp,
        brush = if (selected) grad(PurpleSoft, Purple) else null,
        onClick = onClick
    ) {
        Column(Modifier.fillMaxWidth().padding(vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = if (selected) Color.White else Muted, modifier = Modifier.size(20.dp))
            Spacer(Modifier.height(2.dp))
            Text(label, color = if (selected) Color.White else Ink, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@Composable
private fun InputBox(value: String, onChange: (String) -> Unit, hint: String, minLines: Int = 1) {
    Box(Modifier.fillMaxWidth().clayInset(18.dp).padding(14.dp)) {
        if (value.isEmpty()) Text(hint, color = Muted, fontSize = 13.sp)
        BasicTextField(
            value = value,
            onValueChange = onChange,
            modifier = Modifier.fillMaxWidth().heightIn(min = (minLines * 22).dp),
            textStyle = TextStyle(color = Ink, fontSize = 14.sp),
            cursorBrush = SolidColor(Purple),
            minLines = minLines
        )
    }
}

private data class Cat(val name: String, val icon: ImageVector, val c1: Color, val c2: Color)

// ---------- App ----------
@Composable
private fun NexuraApp(context: Context, incoming: SavedItem?) {
    val prefs = remember { context.getSharedPreferences("nexura_save", Context.MODE_PRIVATE) }
    var items by remember { mutableStateOf(loadItems(prefs)) }
    var selected by remember { mutableStateOf("All Items") }
    var query by remember { mutableStateOf("") }
    var showEditor by remember { mutableStateOf(incoming != null) }
    var editTitle by remember { mutableStateOf(incoming?.title.orEmpty()) }
    var editContent by remember { mutableStateOf(incoming?.content.orEmpty()) }
    var editKind by remember { mutableStateOf(incoming?.kind ?: "Note") }
    var toastText by remember { mutableStateOf("") }

    fun persist(newItems: List<SavedItem>) {
        items = newItems
        prefs.edit().putString("items", JSONArray().apply { newItems.forEach { put(it.toJson()) } }.toString()).apply()
    }

    fun addItem() {
        if (editContent.isBlank() && editTitle.isBlank()) { toastText = "Pehle kuch text ya link likho"; return }
        val c = editContent.trim()
        val k = if (editKind == "Auto") (if (extractUrl(c) != null) "Link" else "Text") else editKind
        persist(listOf(SavedItem(title = editTitle.ifBlank { c.take(48) }, content = c, kind = k, source = if (incoming != null) incoming.source else "Manual")) + items)
        showEditor = false; editTitle = ""; editContent = ""; editKind = "Note"; toastText = "Saved to Nexura Save ✓"
    }

    fun openEditor() { editTitle = ""; editContent = ""; editKind = "Note"; showEditor = true }

    val cats = listOf(
        Cat("All Items", Icons.Rounded.GridView, PurpleSoft, Purple),
        Cat("Videos", Icons.Rounded.Videocam, PinkSoft, Pink),
        Cat("Links", Icons.Rounded.Link, SkySoft, Sky),
        Cat("Images", Icons.Rounded.Image, MintSoft, Mint),
        Cat("Notes", Icons.Rounded.StickyNote2, SunnySoft, Sunny),
        Cat("Favorites", Icons.Rounded.Favorite, PinkSoft, Color(0xFFFF6B6B))
    )

    MaterialTheme(colorScheme = lightColorScheme(primary = Purple, background = BgTop, surface = ClayCard, onBackground = Ink)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(BgTop, BgBottom)))) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                // Header
                Row(
                    Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconBadge(Icons.Rounded.Bookmark, PurpleSoft, Purple, 50.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Nexura Save", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                        Text("Save anything. Find it anytime.", color = Muted, fontSize = 12.sp)
                    }
                    IconBadge(Icons.Rounded.AutoAwesome, SunnySoft, Sunny, 44.dp)
                }
                // Search
                Row(
                    Modifier.padding(horizontal = 20.dp).fillMaxWidth().clayInset(22.dp).padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Search, null, tint = Purple, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(10.dp))
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        textStyle = TextStyle(color = Ink, fontSize = 14.sp),
                        cursorBrush = SolidColor(Purple),
                        decorationBox = { inner ->
                            Box {
                                if (query.isEmpty()) Text("Search saved items...", color = Muted, fontSize = 14.sp)
                                inner()
                            }
                        }
                    )
                    if (query.isNotEmpty()) {
                        Icon(Icons.Rounded.Close, null, tint = Muted, modifier = Modifier.size(20.dp).clickable { query = "" })
                    }
                }

                val filtered = items.filter { item ->
                    (selected == "All Items" ||
                        selected == "Favorites" && item.favorite ||
                        selected == "Videos" && item.kind == "Video" ||
                        selected == "Links" && item.kind == "Link" ||
                        selected == "Images" && item.kind == "Image" ||
                        selected == "Notes" && (item.kind == "Note" || item.kind == "Text")) &&
                        (query.isBlank() || item.title.contains(query, true) || item.content.contains(query, true))
                }

                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 24.dp)
                ) {
                    item {
                        Column {
                            Text("YOUR LIBRARY", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Spacer(Modifier.height(14.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                cats.chunked(3).forEach { rowCats ->
                                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                        rowCats.forEach { cat ->
                                            val count = when (cat.name) {
                                                "All Items" -> items.size
                                                "Videos" -> items.count { it.kind == "Video" }
                                                "Links" -> items.count { it.kind == "Link" }
                                                "Images" -> items.count { it.kind == "Image" }
                                                "Notes" -> items.count { it.kind == "Note" || it.kind == "Text" }
                                                else -> items.count { it.favorite }
                                            }
                                            val sel = selected == cat.name
                                            Clay(
                                                Modifier.weight(1f),
                                                radius = 24.dp,
                                                brush = if (sel) grad(PurpleSoft, Purple) else null,
                                                onClick = { selected = cat.name }
                                            ) {
                                                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                                                    IconBadge(cat.icon, cat.c1, cat.c2, 38.dp)
                                                    Spacer(Modifier.height(10.dp))
                                                    Text(cat.name, color = if (sel) Color.White else Ink, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, maxLines = 1)
                                                    Text("$count saved", color = if (sel) Color(0xFFE8E3FF) else Muted, fontSize = 11.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (selected == "All Items") "Recently Saved" else selected, color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.weight(1f))
                            Text("${items.size} total", color = Muted, fontSize = 12.sp)
                        }
                    }
                    if (filtered.isEmpty()) {
                        item {
                            Column(Modifier.fillMaxWidth().padding(vertical = 30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                IconBadge(Icons.Rounded.BookmarkBorder, PurpleSoft, Purple, 84.dp)
                                Spacer(Modifier.height(18.dp))
                                Text(if (query.isBlank()) "Your library is waiting" else "No matching saves", color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                Spacer(Modifier.height(4.dp))
                                Text("Share from any app or tap + to save something.", color = Muted, fontSize = 12.sp)
                            }
                        }
                    } else {
                        items(filtered, key = { it.id }) { item ->
                            val brand = remember(item.id, item.content, item.kind) { brandFor(item) }
                            val isFileUri = item.content.startsWith("content://") || item.content.startsWith("file://")
                            val shownContent = if (isFileUri) "Shared ${item.kind.lowercase(Locale.ROOT)} file" else item.content
                            val hasUrl = extractUrl(item.content) != null || isFileUri
                            Clay(
                                Modifier.fillMaxWidth(),
                                radius = 26.dp,
                                onClick = { openItem(context, item) { toastText = it } }
                            ) {
                                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    BrandBadge(brand, 54.dp)
                                    Spacer(Modifier.width(14.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(item.title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(shownContent, color = Muted, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                        Spacer(Modifier.height(6.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                if (hasUrl) Icons.AutoMirrored.Rounded.OpenInNew else Icons.Rounded.ContentCopy,
                                                null, tint = Purple, modifier = Modifier.size(13.dp)
                                            )
                                            Spacer(Modifier.width(4.dp))
                                            Text(actionLabel(item, brand), color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                        Spacer(Modifier.height(2.dp))
                                        Text(
                                            "${brand.label}  •  ${SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(item.created))}",
                                            color = Muted, fontSize = 10.sp
                                        )
                                    }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Box(
                                            Modifier.size(34.dp).clickable { persist(items.map { if (it.id == item.id) it.copy(favorite = !it.favorite) else it }) },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                if (item.favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                                                null, tint = if (item.favorite) Pink else Muted, modifier = Modifier.size(23.dp)
                                            )
                                        }
                                        Box(
                                            Modifier.size(34.dp).clickable { persist(items.filterNot { it.id == item.id }) },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Rounded.Delete, null, tint = Danger, modifier = Modifier.size(22.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Bottom bar
                Clay(Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 6.dp, bottom = 14.dp), radius = 30.dp, depth = 8.dp) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        NavItem(Icons.Rounded.Home, "Home", selected == "All Items") { selected = "All Items" }
                        NavItem(Icons.Rounded.Favorite, "Saved", selected == "Favorites") { selected = "Favorites" }
                        Clay(
                            Modifier.size(58.dp),
                            radius = 22.dp,
                            brush = grad(PurpleSoft, Purple),
                            depth = 6.dp,
                            onClick = { openEditor() },
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Rounded.Add, "Add", tint = Color.White, modifier = Modifier.size(30.dp)) }
                        NavItem(Icons.Rounded.Link, "Links", selected == "Links") { selected = "Links" }
                        NavItem(Icons.Rounded.StickyNote2, "Notes", selected == "Notes") { selected = "Notes" }
                    }
                }
            }

            if (showEditor) {
                Dialog(onDismissRequest = { showEditor = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
                    Box(Modifier.fillMaxWidth().padding(16.dp)) {
                        Clay(Modifier.fillMaxWidth(), radius = 32.dp, depth = 10.dp) {
                            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconBadge(Icons.Rounded.Bookmark, PurpleSoft, Purple, 44.dp)
                                    Spacer(Modifier.width(12.dp))
                                    Column {
                                        Text(if (incoming != null) "Save shared item" else "Save something", color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                                        Text("Links, messages, ideas or notes", color = Muted, fontSize = 12.sp)
                                    }
                                }
                                InputBox(editTitle, { editTitle = it }, "Title (optional)")
                                InputBox(editContent, { editContent = it }, "Paste a link or write something", 5)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(
                                        "Auto" to Icons.Rounded.AutoAwesome,
                                        "Note" to Icons.Rounded.StickyNote2,
                                        "Link" to Icons.Rounded.Link,
                                        "Video" to Icons.Rounded.Videocam,
                                        "Image" to Icons.Rounded.Image
                                    ).forEach { (k, ic) -> KindChip(k, ic, editKind == k) { editKind = k } }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Clay(Modifier.weight(1f), radius = 20.dp, depth = 5.dp, onClick = { showEditor = false }, contentAlignment = Alignment.Center) {
                                        Text("Cancel", color = Ink, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 14.dp))
                                    }
                                    Clay(Modifier.weight(1f), radius = 20.dp, depth = 5.dp, brush = grad(PurpleSoft, Purple), onClick = { addItem() }, contentAlignment = Alignment.Center) {
                                        Text("Save item", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 14.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (toastText.isNotBlank()) {
                LaunchedEffect(toastText) { Toast.makeText(context, toastText, Toast.LENGTH_SHORT).show(); toastText = "" }
            }
        }
    }
}

private fun SavedItem.toJson() = JSONObject().apply { put("id", id); put("title", title); put("content", content); put("kind", kind); put("source", source); put("created", created); put("favorite", favorite) }

private fun loadItems(prefs: android.content.SharedPreferences): List<SavedItem> = try {
    val a = JSONArray(prefs.getString("items", "[]"))
    (0 until a.length()).map { i ->
        val o = a.getJSONObject(i)
        SavedItem(o.optString("id", UUID.randomUUID().toString()), o.optString("title"), o.optString("content"), o.optString("kind", "Note"), o.optString("source", "Manual"), o.optLong("created", System.currentTimeMillis()), o.optBoolean("favorite", false))
    }
} catch (_: Exception) { emptyList() }
