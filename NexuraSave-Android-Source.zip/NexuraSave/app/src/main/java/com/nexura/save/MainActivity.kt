package com.nexura.save

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private val Bg = Color(0xFF090D22)
private val Panel = Color(0xFF151C3C)
private val Purple = Color(0xFF9B5CFF)
private val Cyan = Color(0xFF65D8FF)
private val Muted = Color(0xFFAAB4D8)

data class SavedItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val content: String,
    val kind: String,
    val source: String = "Manual",
    val created: Long = System.currentTimeMillis(),
    val favorite: Boolean = false
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val incoming = parseIncoming(intent)
        setContent { NexuraApp(this, incoming) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }

    private fun parseIncoming(i: Intent?): SavedItem? {
        if (i == null || (i.action != Intent.ACTION_SEND && i.action != Intent.ACTION_SEND_MULTIPLE)) return null
        val sharedText = i.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
        val subject = i.getStringExtra(Intent.EXTRA_SUBJECT).orEmpty()
        val uri = if (i.action == Intent.ACTION_SEND) i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM) else null
        val mime = i.type.orEmpty()
        val content = when {
            sharedText.isNotBlank() -> sharedText
            uri != null -> uri.toString()
            else -> "Shared content"
        }
        val kind = when {
            mime.startsWith("video/") -> "Video"
            mime.startsWith("image/") -> "Image"
            content.contains("http://") || content.contains("https://") -> "Link"
            else -> "Text"
        }
        return SavedItem(title = subject.ifBlank { content.take(64).ifBlank { "Saved $kind" } }, content = content, kind = kind, source = "Share menu")
    }
}

@Composable
private fun NexuraApp(context: Context, incoming: SavedItem?) {
    val prefs = remember { context.getSharedPreferences("nexura_save", Context.MODE_PRIVATE) }
    var items by remember { mutableStateOf(loadItems(prefs)) }
    var selected by remember { mutableStateOf("All Items") }
    var query by remember { mutableStateOf("") }
    var showEditor by remember { mutableStateOf(incoming != null) }
    var editTitle by remember { mutableStateOf(incoming?.title.orEmpty()) }
    var editContent by remember { mutableStateOf(incoming?.content.orEmpty()) }
    var editKind by remember { mutableStateOf(incoming?.kind ?: "Note") }
    var toastText by remember { mutableStateOf("") }

    fun persist(newItems: List<SavedItem>) { items = newItems; prefs.edit().putString("items", JSONArray().apply { newItems.forEach { put(it.toJson()) } }.toString()).apply() }
    fun addItem() {
        if (editContent.isBlank() && editTitle.isBlank()) { toastText = "Pehle kuch text ya link likho"; return }
        val c = editContent.trim()
        val k = if (editKind == "Auto") if (c.startsWith("http://") || c.startsWith("https://")) "Link" else "Text" else editKind
        persist(listOf(SavedItem(title = editTitle.ifBlank { c.take(48) }, content = c, kind = k, source = if (incoming != null) incoming.source else "Manual")) + items)
        showEditor = false; editTitle = ""; editContent = ""; editKind = "Note"; toastText = "Saved to Nexura Save ✓"
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = Panel, onBackground = Color.White)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF111A3B), Bg, Color(0xFF160E35))))) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 18.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(46.dp).background(Brush.linearGradient(listOf(Purple, Color(0xFF5C5BFF))), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) { Text("N", fontSize = 26.sp, fontWeight = FontWeight.Black, color = Color.White) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text("Nexura Save", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Color.White); Text("Save anything. Find it anytime.", color = Muted, fontSize = 12.sp) }
                    Text("✦", color = Color(0xFFFFC85A), fontSize = 27.sp)
                }
                Surface(shape = RoundedCornerShape(22.dp), color = Color(0xFF1A2348), tonalElevation = 6.dp, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(horizontal = 15.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("⌕", color = Cyan, fontSize = 25.sp); Spacer(Modifier.width(10.dp))
                        BasicTextField(value = query, onValueChange = { query = it }, singleLine = true, modifier = Modifier.weight(1f), textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp), decorationBox = { inner -> if (query.isEmpty()) Text("Search saved items...", color = Muted, fontSize = 14.sp); inner() })
                    }
                }
                Spacer(Modifier.height(18.dp))
                Text("YOUR LIBRARY", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Spacer(Modifier.height(10.dp))
                val cats = listOf("All Items" to "▦", "Videos" to "▶", "Links" to "↗", "Images" to "▧", "Notes" to "▤", "Favorites" to "♡")
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    cats.chunked(3).forEach { rowCats -> Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) { rowCats.forEach { (name, icon) ->
                        val count = when (name) { "All Items" -> items.size; "Videos" -> items.count { it.kind == "Video" }; "Links" -> items.count { it.kind == "Link" }; "Images" -> items.count { it.kind == "Image" }; "Notes" -> items.count { it.kind == "Note" || it.kind == "Text" }; else -> items.count { it.favorite } }
                        Surface(modifier = Modifier.weight(1f).clickable { selected = name }, shape = RoundedCornerShape(20.dp), color = if (selected == name) Color(0xFF34235F) else Panel, tonalElevation = if (selected == name) 8.dp else 2.dp) {
                            Column(Modifier.padding(13.dp)) { Text(icon, color = if (selected == name) Color(0xFFD5B6FF) else Cyan, fontSize = 23.sp); Spacer(Modifier.height(7.dp)); Text(name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, maxLines = 1); Text("$count saved", color = Muted, fontSize = 11.sp) }
                        }
                    } } }
                }
                Spacer(Modifier.height(20.dp))
                Row(verticalAlignment = Alignment.CenterVertically) { Text(if (selected == "All Items") "Recently Saved" else selected, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Text("${items.size} total", color = Muted, fontSize = 12.sp) }
                Spacer(Modifier.height(10.dp))
                val filtered = items.filter { item ->
                    (selected == "All Items" || selected == "Favorites" && item.favorite || selected == "Videos" && item.kind == "Video" || selected == "Links" && item.kind == "Link" || selected == "Images" && item.kind == "Image" || selected == "Notes" && (item.kind == "Note" || item.kind == "Text")) && (query.isBlank() || item.title.contains(query, true) || item.content.contains(query, true))
                }
                if (filtered.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("✧", fontSize = 48.sp, color = Purple); Text(if (query.isBlank()) "Your library is waiting" else "No matching saves", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp); Text("Share from any app or tap + to save something.", color = Muted, fontSize = 12.sp) } }
                } else {
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                        items(filtered, key = { it.id }) { item ->
                            Surface(shape = RoundedCornerShape(20.dp), color = Color(0xD91A2144), tonalElevation = 5.dp, modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(48.dp).background(Brush.linearGradient(listOf(Color(0xFF373D80), Color(0xFF22284F))), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) { Text(when (item.kind) { "Video" -> "▶"; "Link" -> "↗"; "Image" -> "▧"; else -> "▤" }, fontSize = 22.sp, color = Color(0xFFBFA0FF)) }
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) { Text(item.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(item.content, color = Muted, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis); Spacer(Modifier.height(4.dp)); Text("${item.kind}  •  ${SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(item.created))}", color = Color(0xFF8F9AC6), fontSize = 10.sp) }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(if (item.favorite) "♥" else "♡", color = if (item.favorite) Color(0xFFFF75C8) else Muted, fontSize = 22.sp, modifier = Modifier.clickable { persist(items.map { if (it.id == item.id) it.copy(favorite = !it.favorite) else it }) }); Text("×", color = Color(0xFFFF7A92), fontSize = 20.sp, modifier = Modifier.clickable { persist(items.filterNot { it.id == item.id }) }) }
                                }
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFF1B2449), modifier = Modifier.weight(1f).clickable { selected = "All Items" }) { Column(Modifier.padding(11.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text("⌂", color = Purple, fontSize = 21.sp); Text("Home", color = Color.White, fontSize = 10.sp) } }
                    Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFF1B2449), modifier = Modifier.weight(1f).clickable { selected = "Favorites" }) { Column(Modifier.padding(11.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text("♡", color = Color(0xFFFF75C8), fontSize = 21.sp); Text("Saved", color = Color.White, fontSize = 10.sp) } }
                    Surface(shape = RoundedCornerShape(20.dp), color = Purple, modifier = Modifier.size(62.dp).clickable { editTitle = ""; editContent = ""; editKind = "Note"; showEditor = true }, shadowElevation = 12.dp) { Box(contentAlignment = Alignment.Center) { Text("+", color = Color.White, fontSize = 35.sp) } }
                    Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFF1B2449), modifier = Modifier.weight(1f).clickable { selected = "Links" }) { Column(Modifier.padding(11.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text("↗", color = Cyan, fontSize = 21.sp); Text("Links", color = Color.White, fontSize = 10.sp) } }
                    Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFF1B2449), modifier = Modifier.weight(1f).clickable { selected = "Notes" }) { Column(Modifier.padding(11.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text("▤", color = Color(0xFFFFC85A), fontSize = 21.sp); Text("Notes", color = Color.White, fontSize = 10.sp) } }
                }
            }
            if (showEditor) {
                androidx.compose.ui.window.Dialog(onDismissRequest = { showEditor = false }) {
                    Surface(shape = RoundedCornerShape(28.dp), color = Color(0xFF171D3D), tonalElevation = 12.dp) {
                        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                            Text(if (incoming != null) "Save shared item" else "Save something", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 21.sp)
                            Text("Links, messages, ideas or notes", color = Muted, fontSize = 12.sp)
                            InputBox(editTitle, { editTitle = it }, "Title (optional)")
                            InputBox(editContent, { editContent = it }, "Paste a link or write something", 5)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Auto", "Note", "Link", "Video", "Image").forEach { k -> FilterChip(selected = editKind == k, onClick = { editKind = k }, label = { Text(k, fontSize = 11.sp) }) } }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedButton(onClick = { showEditor = false }, modifier = Modifier.weight(1f)) { Text("Cancel") }
                                Button(onClick = { addItem() }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("Save item") }
                            }
                        }
                    }
                }
            }
            if (toastText.isNotBlank()) {
                LaunchedEffect(toastText) { Toast.makeText(context, toastText, Toast.LENGTH_SHORT).show(); toastText = "" }
            }
        }
    }
}

@Composable
private fun InputBox(value: String, onChange: (String) -> Unit, hint: String, minLines: Int = 1) {
    Surface(shape = RoundedCornerShape(16.dp), color = Color(0xFF0E1430)) {
        Box(Modifier.fillMaxWidth().padding(13.dp)) {
            if (value.isEmpty()) Text(hint, color = Muted, fontSize = 13.sp)
            BasicTextField(value = value, onValueChange = onChange, modifier = Modifier.fillMaxWidth().heightIn(min = (minLines * 22).dp), textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 13.sp), minLines = minLines)
        }
    }
}

private fun SavedItem.toJson() = JSONObject().apply { put("id", id); put("title", title); put("content", content); put("kind", kind); put("source", source); put("created", created); put("favorite", favorite) }
private fun loadItems(prefs: android.content.SharedPreferences): List<SavedItem> = try {
    val a = JSONArray(prefs.getString("items", "[]"))
    (0 until a.length()).map { i -> val o = a.getJSONObject(i); SavedItem(o.optString("id", UUID.randomUUID().toString()), o.optString("title"), o.optString("content"), o.optString("kind", "Note"), o.optString("source", "Manual"), o.optLong("created", System.currentTimeMillis()), o.optBoolean("favorite", false)) }
} catch (_: Exception) { emptyList() }
